driver name /dev/stopwatch
device driver major number 242

/data/local/tmp

insmod stopwatch.ko
mknod /dev/stopwatch c 242 0
./HW3_20141542.out
