How to Run Eclipse

cd /work/mydroid/adt-bundle-linux-x86_64-20140702/eclipse

./eclipe
